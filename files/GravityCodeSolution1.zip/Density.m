function [rho] = Density(r,m,rho_0,G,c,gamma)
%RHO Summary of this function goes here
%   Detailed explanation goes here
rho=-(rho_0*c^2+rho_0^gamma)*(m*c^2+4*pi*r^3*rho_0^gamma)...
    /(gamma*rho_0^(gamma-1)*r*(c^2*r-2*G*m)*c^2/G);
end

