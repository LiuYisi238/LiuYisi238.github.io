clear;
close all;
clc;


G=1;
rho0=1;
c=1;
rho_0=1;
C=8*pi*G*rho0/(3*c^2);
Rmax=sqrt(1/C);
R0=0.3;
R=min(R0,Rmax);
r1=0:0.01:R;
P1=(sqrt(1-C*r1.^2)-sqrt(1-C*R^2))./(3*sqrt(1-C*R^2)-sqrt(1-C*r1.^2));

figure(1)
plot(r1,P1);
title('Pressure P versus Radius r')
xlabel('Radius r');
ylabel('Pressure P');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gamma=0.8:0.1:1.2;
R2=2;
delta_r=0.001;

figure(2)
for j=1:length(gamma)
    r2=delta_r:delta_r:R2;
    m2=linspace(0,0,length(r2));
    rho2=linspace(0,0,length(r2));
    P2=linspace(0,0,length(r2));
    m20=0;
    rho20=1;
    P20=rho20^gamma(j);
    m2(1)=m20;
    rho2(1)=rho20;
    P2(1)=P20;
    for i=1:(length(r2)-1)
    m2(i+1)=m2(i)+Mass(r2(i),rho2(i))*delta_r;
    rho2(i+1)=rho2(i)+Density(r2(i),m2(i+1),rho2(i),G,c,gamma(j))*delta_r;
    P2(i+1)=rho2(i+1)^gamma(j);
    end
    plot(r2,P2);
    hold on;
end

plot(r1,P1);
title('Pressure P versus Radius r');
xlabel('Radius r');
ylabel('Pressure P');
legend('gamma=0.8','gamma=0.9','gamma=1.0','gamma=1.1','gamma=1.2'...
    ,'rho=constant');
hold off;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


r_g=1;
r=r_g:0.01:10*r_g;
z1=sqrt(4*r_g.*(r-r_g));
z2=-z1;

figure(3)
plot(r,z1,'b');
hold on;
plot(r,z2,'r');
xlabel('r');
ylabel('z');
title('z versus r');
