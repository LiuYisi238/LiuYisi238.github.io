function [m] = Mass(r,rho)
%MASS Summary of this function goes here
%   Detailed explanation goes here
m = 4*pi*r^2*rho;
end

